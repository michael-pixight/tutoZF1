-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le: Jeu 21 Février 2013 à 17:58
-- Version du serveur: 5.5.24-log
-- Version de PHP: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `tutozf1`
--

-- --------------------------------------------------------

--
-- Structure de la table `albums`
--

CREATE TABLE IF NOT EXISTS `albums` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `artiste` varchar(100) NOT NULL,
  `titre` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Contenu de la table `albums`
--

INSERT INTO `albums` (`id`, `artiste`, `titre`) VALUES
(8, 'Florence + The Machine', 'Lungs'),
(9, 'Massive Attack', 'Heligoland'),
(10, 'Andre Rieu', 'Forever Vienna'),
(11, 'Sade', 'Soldier of Love'),
(12, 'Jonsi', 'Go'),
(13, 'Sunny Side', 'Paolo Monty');

-- --------------------------------------------------------

--
-- Structure de la table `entreprises`
--

CREATE TABLE IF NOT EXISTS `entreprises` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `entreprises`
--

INSERT INTO `entreprises` (`id`, `name`) VALUES
(1, 'Entreprise Teste modifiÃ©e');

-- --------------------------------------------------------

--
-- Structure de la table `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT 'guest',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `roles`
--

INSERT INTO `roles` (`id`, `name`) VALUES
(1, 'guest'),
(2, 'user'),
(3, 'admin'),
(4, 'superadmin');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `salt` varchar(50) NOT NULL,
  `role` varchar(50) NOT NULL DEFAULT 'guest',
  `roles_id` int(11) NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Contenu de la table `users`
--

INSERT INTO `users` (`user_id`, `firstname`, `lastname`, `mail`, `username`, `password`, `salt`, `role`, `roles_id`, `date_created`) VALUES
(1, 'Michael', 'de Cadaran', 'michael@pixight.net', 'mic', 'b06681dc827c9a097a8dd3ddd7f7bf37', '9317711888910', 'admin', 4, '2013-02-06 16:54:30'),
(4, 'bob', 'bob', 'boby@boby.fr', 'bob', '98bb09b0e894987c39f30d6f4b7104e2', '1.8301676390322E+14', '1', 3, '0000-00-00 00:00:00'),
(5, 'bill', 'bill', 'bill@bill.fr', 'bill', '498de7a39fd34a253ea78078156b6a07', '1.102394475813E+14', '1', 2, '0000-00-00 00:00:00'),
(7, 'joe', 'joe', 'joe@joe.fr', 'joe', 'c8571f8341c3feb1fd7067c6b24eb84f', '1.9034250642056E+14', '2', 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Structure de la table `users_roles`
--

CREATE TABLE IF NOT EXISTS `users_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL,
  `roles_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `users_roles`
--

INSERT INTO `users_roles` (`id`, `users_id`, `roles_id`) VALUES
(1, 1, 4),
(2, 4, 1),
(3, 5, 2),
(4, 7, 4);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
